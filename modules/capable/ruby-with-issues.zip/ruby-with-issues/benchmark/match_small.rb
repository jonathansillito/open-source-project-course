1000000.times { 'haystack'.match(/hay/) }
