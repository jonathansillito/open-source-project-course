arr = [*0...100000]
10_000.times {arr.sample 100}
