#
# Issue #1
#
# The following code leads to a segfault after the first successful read. The expected behavior is that it should throw an IOError instead.
#
file = File.open("../test.rb")

file.each_byte do |byte|
  p byte
  file.close
end

#
# Issue #2

# Background: Array#pack takes an array of ruby objects and formats them into binary representations suitable for storage or transmission in various contexts. The "m" directive in Array#pack is used for Base64 encoding. It takes the elements of the array, treats them as binary data, and encodes them into a Base64 string. In the following the "m" directive is followed by a number which specifies the line length for the encoded output.
#
# The following code leads to a segfault. Why?
#
["a"*3070].pack("m4000")
["a"*(3072*3-2)].pack("m3072")